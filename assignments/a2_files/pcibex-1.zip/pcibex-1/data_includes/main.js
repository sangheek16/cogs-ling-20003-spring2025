// TODO: change the sequence of the items so that the "practice" item shows up before the "critical" and "filler" trials
var shuffleSequence = seq(rshuffle(startsWith("critical"), startsWith("filler"))); // NOTE: Don't remove the semi-colon!

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        instructions: "Is this a real word?",
        as: ["F: No", "J: Yes"]
    }
]; // NOTE: Don't remove the semi-colon!

var items = [
    
    ["setcounter", "__SetCounter__", { }],

    // TODO: include THREE practice items.
    // These are trials that help participants get used to a lexical decision task.
    // They should have a format of a lexical decision task, 
    // but the words should be something that aren't used in critical or filler items.

    // NOTE: Below are the critical trials

    [["critical_sem", 1], 
    "Message", { html: '<center> + <p> Look at the + and press any key to proceed. </p> </center>',
                transfer: "keypress" 
            },
    "Message", { html: '<center> whale </center>', 
                transfer: 100 
            }, 
    "Message", { html: ' ', 
                transfer: 200
            }, 
    "AcceptabilityJudgment", { 
        s: { html: 'shark' } 
    }], // NOTE: Don't forget the comma

    // TODO: include the two other conditions for item 1.

    // TODO: include the rest of the critical items (items 2-15) for all three conditions.

    // NOTE: Below are the filler trials
    [["filler", 16], 
    "Message", { html: '<center> + <p> Look at the + and press any key to proceed. </p> </center>',
                transfer: "keypress" 
            },
    "Message", { html: '<center> cat </center>', 
                transfer: 100 
            }, 
    "Message", { html: ' ', 
                transfer: 200
            }, 
    "AcceptabilityJudgment", { 
        s: { html: 'thafe' } 
    }],

    // TODO: include the rest of the filler items (items 17-30).

    // NOTE: There should be NO comma after the final bracket (])!

]; // NOTE: Don't remove the semi-colon!

// TODO: include your comment here:
// 