PennController.ResetPrefix()

DebugOff()

// TODO: add a goodbye Message after the experiment

var shuffleSequence = seq("setcounter", "info", "intro", sepWith("sep", seq("practice", "practiceover", rshuffle(startsWith("e"),startsWith("f")))));
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        //errorMessage: "Wrong. Please wait for the next sentence."
        ignoreFailure: "true"
    },
    "DashedSentence", {
        /* https://github.com/addrummond/ibex/blob/master/docs/manual.md#dashedsentence

           mode: either "self-paced reading" or "speeded acceptability"
           wordTime: n (relevant when mode is set as "speeded acceptability")
           hideUnderscores: set as 'true' if multiple words need be showed (space by _)
        */
        hideUnderscores: true,
        mode: "self-paced reading"
        // mode: "speeded acceptability",
        // wordTime: 1000
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
     "DashedAcceptabilityJudgment", {
        mode: "self-paced reading",
        display: "dashed",
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "On a 1-7 scale, how acceptable is the sentence you just saw? Click a box above or press a number key to answer.",
        leftComment: "(Completely unacceptable)", rightComment: "(Completely acceptable)"
    },
    "Question", {
        hasCorrect: false,  // change this when needed
        randomOrder: false, // change this when you are doing a different task ('False' for acceptability 1-7 judgment task)
        showNumbers: false,
        presentHorizontally: true,
        instructions: "Press 'f' for YES ______________________ Press 'j' for NO"
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    ["sep", "Separator", { }],

    ["setcounter", "__SetCounter__", { }],

    ["info", "Form", {html: {include: "participant-info.html" }} ],
    ["intro", "Form", {html: {include: "instruction1.html" }} ],
    ["intro", "Form", {html: {include: "instruction2.html" }} ],
    ["intro", "Form", {html: {include: "instruction3.html" }} ],

    ["practiceover", "Message", {html: 
        ["div",
        ["p", "This is the end of the practice."],
        ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
        ],
        continueMessage:"Click here to continue."
        }
    ],

    // ["presep", Separator, { transfer: 2000, normalMessage: "Please get ready. We will start. Please wait..." }],

    
    // An example for self-paced reading, with comprehension question task
    // NOTE: As you can see, either s: "SENTENCE" or s: ["word_1", ... "word_n"] format works.
    ["practice", "DashedSentence", {s: "A sentence can have a relative clause."}],
    ["practice", "DashedSentence", {s: ["Press", "the", "spacebar,", "and", "you", "will", "see", "the", "next", "words."]}],
    
    ["practice", "DashedSentence", {s: ["Each", "sentence", "will", "be", "followed", "by", "a", "comprehension", "question."]}],
    ["practice", "DashedSentence", {s: ["You", "will", "need", "to", "answer", "to", "each", "question,", "by", "responding", "either", "yes,", "or", "no."]}],
    ["practice", "DashedSentence", {s: ["Press", "f", "key", "for", "'yes'", "and", "j", "key", "for", "'no'"]}],
    ["practice", "DashedSentence", {s: ["If", "you're", "not", "sure", "what", "the", "answer", "is,", "make", "a", "guess!"]}],

    ["practice", "DashedSentence", {s: ["Now", "let's", "practice!"]}],

    ["practice", "DashedSentence", {s: ["It", "appears", "that", "those", "clerks", "and", "coordinators", "organized", "the", "calendar."]}, "Question", {q: "Did the clerks and coordinators organize the calendar?", as: [["f","yes"],["j","no"]]}],
    ["practice", "DashedSentence", {s: ["Jamie", "is", "a", "famous", "pianist", "in", "Australia."]}, "Question", {q: "Is Jamie a famous violinist?", as: [["f","yes"],["j","no"]]}],
    ["practice", "DashedSentence", {s: ["It", "is", "Eunice", "who", "the", "officer", "was", "looking", "for", "all", "night."]}, "Question", {q: "Was the officer looking for Eunice?", as: [["f","yes"],["j","no"]]}],
    ["practice", "DashedSentence", {s: ["This", "is", "the", "last", "practice", "sentence", "before", "the", "experiment", "begins."]}, "Question", {q: "Is this the last practice sentence?", as: [["f","yes"],["j","no"]]}],
    
    //target trials
    //TODO: Fill in 24 target trials; 4 conditions; all should have a question.
    // filler trials
    [["filler", 101], "DashedSentence", {s: ["It", "seemed", "incredible", "to", "the", "spectators", "that", "the", "game", "was", "still", "going", "on", "after", "5", "hours."]}, "Question", {q: "Was it a quick game?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 102], "DashedSentence", {s: ["It", "wasn't", "obvious", "to", "the", "scorers", "that", "the", "figure", "skater", "had", "fulfilled", "all", "of", "the", "technical", "requirements."]}, "Question", {q: "Was it obvious to the scorers that the skater finished the requirements?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 103], "DashedSentence", {s: ["It", "was", "disturbing", "to", "the", "vice", "president", "that", "the", "division's", "productivity", "had", "dropped", "by", "50%."]}, "Question", {q: "Was the division's performance disturbing to the vice president?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 104], "DashedSentence", {s: ["It", "seemed", "wonderful", "to", "the", "foreigners", "that", "Delaware", "had", "no", "sales", "tax."]}, "Question", {q: "Was it Delaware that had no sales tax?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 105], "DashedSentence", {s: ["It", "was", "surprising", "to", "Dominique", "that", "the", "big", "basketball", "game", "hadn't", "sold", "out."]}, "Question", {q: "Was Dominique surprised that the game hadn't sold out?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 106], "DashedSentence", {s: ["The", "computer", "virus", "that", "threw", "the", "business", "world", "into", "chaos", "this", "week", "was", "designed", "by", "a", "14-year-old."]}, "Question", {q: "Was it a high school teen that was responsible for the computer virus?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 107], "DashedSentence", {s: ["The", "FDA", "hadn't", "recalled", "the", "drug", "yet,", "although", "they", "had", "at", "least", "issued", "a", "cautionary", "statement."]}, "Question", {q: "Had the FDA recalled the drug yet?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 108], "DashedSentence", {s: ["Jeremy", "was", "interested", "in", "the", "physicist's", "new", "theory,", "even", "though", "he", "didn't", "understand", "the", "details."]}, "Question", {q: "Did Jeremy understand the details?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 109], "DashedSentence", {s: ["Barry", "was", "glad", "there", "was", "a", "police", "station", "nearby,", "but", "so", "far", "he", "hadn't", "had", "any", "difficulties."]}, "Question", {q: "Had Barry had any difficulties yet?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 110], "DashedSentence", {s: ["The", "park", "was", "full", "of", "people", "although", "it", "was", "a", "little", "cold", "outside."]}, "Question", {q: "Was it warm outside?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 111], "DashedSentence", {s: ["Craig", "suspected", "the", "children", "were", "staying", "up", "late", "to", "play", "games."]}, "Question", {q: "Did Craig think the children were playing games?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 112], "DashedSentence", {s: ["The", "children", "hadn't", "calmed", "down,", "though", "it", "was", "way", "past", "bedtime."]}, "Question", {q: "Was it past the children's bedtime?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 113], "DashedSentence", {s: ["Everyone", "thought", "that", "the", "roadside", "stand", "had", "the", "best", "fried", "chicken", "in", "town."]}, "Question", {q: "Was it the KFC in the mall that had the town's best fried chicken?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 114], "DashedSentence", {s: ["The", "movie", "was", "designed", "to", "be", "a", "tearjerker,", "even", "though", "it", "had", "a", "cheerful", "title."]}, "Question", {q: "Was the title of the movie depressing?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 115], "DashedSentence", {s: ["Everyone", "had", "to", "go", "through", "the", "mandatory", "training,", "which", "the", "administration", "said", "was", "for", "safety", "reasons."]}, "Question", {q: "Was the training mandatory for everyone?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 116], "DashedSentence", {s: ["The", "basement", "would", "leak", "whenever", "it", "rained,", "but", "other", "than", "that", "the", "house", "was", "fine."]}, "Question", {q: "Did the basement leak when it rained?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 117], "DashedSentence", {s: ["Nobody", "expected", "that", "two", "hurricanes", "could", "strike", "the", "state", "in", "the", "same", "week,", "but", "that's", "what", "happened."]}, "Question", {q: "Was it wildfires that struck the state?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 118], "DashedSentence", {s: ["Seth", "classified", "the", "group", "of", "substances", "into", "three", "sub-groups", "according", "to", "their", "chemical", "properties."]}, "Question", {q: "Did Seth manage to classify the substances into five groups?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 119], "DashedSentence", {s: ["After", "Mary", "left", "for", "the", "ballet,", "the", "children", "called", "some", "friends", "to", "come", "over."]}, "Question", {q: "Was it the opera that Mary went to?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 120], "DashedSentence", {s: ["As", "the", "children", "crept", "over", "the", "fence", "protecting", "the", "construction", "site,", "a", "guard", "dog", "started", "barking", "loudly."]}, "Question", {q: "Did the children jump a fence to get to the construction site?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 121], "DashedSentence", {s: ["Russell", "called", "the", "travel", "hotline", "to", "confirm", "the", "flight", "reservations", "before", "Molly", "left", "for", "the", "airport."]}, "Question", {q: "Was it John that called about flight reservations?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 122], "DashedSentence", {s: ["The", "party", "started", "winding", "down", "as", "people", "grew", "increasingly", "bored", "with", "bad", "dance", "music", "and", "drunken", "conversation."]}, "Question", {q: "Was the music good?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 123], "DashedSentence", {s: ["The", "gas", "station", "cashier", "quietly", "called", "the", "police", "while", "the", "suspicious-looking", "man", "was", "in", "the", "bathroom."]}, "Question", {q: "Did the cashier decide to call the police about the suspicious man?", as: [["f","yes"], ["j","no"]]}],
    [["filler", 124], "DashedSentence", {s: ["Although", "the", "stock", "market", "dropped", "sharply,", "most", "specialists", "said", "that", "there", "was", "nothing", "to", "worry", "about."]}, "Question", {q: "Were the specialists concerned?", as: [["f","yes"], ["j","no"]]}],

];